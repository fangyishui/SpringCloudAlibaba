Maven central publication requires a JavaDoc jar. This exists to satisfy that.
